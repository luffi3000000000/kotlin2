package com.example.kotlin2

import android.app.Application
import com.example.kotlin2.domain.repository.NoteRepository

class App: Application() {

}