package com.example.kotlin2.data.model


data class NoteDto(
    val title:String? = null,
    val text: String? = null
)
