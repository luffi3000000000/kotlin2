package com.example.kotlin2.domain.model

data class Note(
    val title:String? = null,
    val text: String? = null
)
